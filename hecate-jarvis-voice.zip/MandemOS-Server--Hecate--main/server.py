
# server.py — entrypoint for gunicorn / python
import sys, os
ROOT = os.path.dirname(os.path.abspath(__file__))
OK = os.path.join(ROOT, "OK workspaces")
if OK not in sys.path:
    sys.path.insert(0, OK)
from main import app  # noqa
if __name__ == "__main__":
    from main import run_server
    run_server()
