
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from hecate import Hecate
import os

app = Flask(__name__, static_folder=None)
CORS(app)
hecate = Hecate()

@app.route("/ping")
def ping():
    return jsonify({"ok": True, "service": "Hecate API", "mode": hecate.operational_mode, "jarvis": hecate.jarvis_mode}), 200

@app.route("/api/respond", methods=["POST"])
def api_respond():
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    reply = hecate.respond(text)
    return jsonify({"reply": reply}), 200

@app.route("/api/state")
def api_state():
    return jsonify({
        "mode": hecate.operational_mode,
        "jarvis": hecate.jarvis_mode,
        "awaiting_password": hecate.jarvis_awaiting_password
    })

# ---- Voice I/O ----
from werkzeug.utils import secure_filename
from voice import eleven_tts_mp3, as_b64_audio_mp3
import tempfile

ALLOWED_AUDIO = {"mp3","mpeg","wav","m4a","mp4","webm","ogg"}

@app.route("/api/voice/voices", methods=["GET"])
def api_voice_voices():
    return jsonify({
        "default_voice_id": os.getenv("ELEVEN_VOICE_ID", "21m00Tcm4TlvDq8ikWAM"),
        "voices": [
            {"id":"21m00Tcm4TlvDq8ikWAM","name":"Rachel"},
            {"id":"AZnzlk1XvdvUeBnXmlld","name":"Bella"},
            {"id":"EXAVITQu4vr4xnSDxMaL","name":"Antoni"},
            {"id":"ErXwobaYiN019PkySvjV","name":"Adam"}
        ]
    })

@app.route("/api/voice/speak", methods=["POST"])
def api_voice_speak():
    data = request.get_json(silent=True) or {}
    text = data.get("text","").strip()
    voice_id = data.get("voice_id")
    if not text:
        return jsonify({"error":"text required"}), 400
    try:
        raw = eleven_tts_mp3(text, voice_id=voice_id)
        return app.response_class(raw, mimetype="audio/mpeg")
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/voice/ingest", methods=["POST"])
def api_voice_ingest():
    if "file" not in request.files:
        return jsonify({"error":"file required"}), 400
    f = request.files["file"]
    filename = secure_filename(f.filename or "audio")
    ext = (filename.rsplit(".",1)[-1].lower() if "." in filename else "wav")
    if ext not in ALLOWED_AUDIO:
        return jsonify({"error":"unsupported audio type"}), 400

    use_tts = request.args.get("tts","0") == "1"
    with tempfile.NamedTemporaryFile(suffix="."+ext, delete=False) as tmp:
        f.save(tmp.name)
        tmp_path = tmp.name

    transcript = None
    try:
        import openai
        client = openai.OpenAI() if hasattr(openai, "OpenAI") else None
        if client:
            with open(tmp_path, "rb") as fh:
                tr = client.audio.transcriptions.create(
                    model="gpt-4o-transcribe",
                    file=fh
                )
            transcript = tr.text.strip()
        else:
            openai.api_key = os.getenv("OPENAI_API_KEY")
            from openai import Audio
            with open(tmp_path, "rb") as fh:
                tr = Audio.transcriptions.create(model="whisper-1", file=fh)
            transcript = tr["text"].strip()
    except Exception as e:
        os.unlink(tmp_path)
        return jsonify({"error": f"transcription failed: {e}"}), 500

    os.unlink(tmp_path)
    reply = hecate.respond(transcript or "")
    out = {"transcript": transcript, "reply": reply}

    if use_tts:
        try:
            raw = eleven_tts_mp3(reply)
            out["audio_b64"] = as_b64_audio_mp3(raw)
        except Exception as e:
            out["audio_error"] = str(e)

    return jsonify(out), 200

@app.route("/", methods=["GET"])
def serve_index():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    index_path = os.path.join(root, "index.html")
    if os.path.exists(index_path):
        return send_from_directory(root, "index.html")
    return "<h1>Hecate API</h1><p>POST /api/respond with {'text': 'hello'}</p>", 200

def run_server():
    port = int(os.getenv("PORT", "10000"))
    app.run(host="0.0.0.0", port=port)

if __name__ == "__main__":
    run_server()
