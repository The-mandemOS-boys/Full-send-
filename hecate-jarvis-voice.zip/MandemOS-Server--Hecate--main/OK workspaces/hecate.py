
import os, json, time, requests, re

class Hecate:
    def __init__(self, name="Hecate", personality="bold and adaptive", coder=True):
        self.name = name
        self.personality = personality
        self.coder = coder
        self.memory_path = os.environ.get("HECATE_MEMORY_FILE", "memory.txt")
        self.openai_key = os.environ.get("OPENAI_API_KEY")
        self.openai_model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        self.ollama_host = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
        self.ollama_model = os.environ.get("OLLAMA_MODEL", "llama3")
        self.jarvis_awaiting_password = False
        self.jarvis_mode = False
        self.operational_mode = "lab"
        self._ensure_memory_file()

    def _ensure_memory_file(self):
        try:
            if not os.path.exists(self.memory_path):
                with open(self.memory_path, "w", encoding="utf-8") as f:
                    f.write("Hecate memory booted @ %s\n" % time.ctime())
        except Exception:
            pass

    def remember(self, fact:str):
        try:
            with open(self.memory_path, "a", encoding="utf-8") as f:
                f.write(fact.strip() + "\n")
            return "🧠 Noted."
        except Exception as e:
            return f"[memory error] {e}"

    def recall(self, last_n:int=20):
        try:
            with open(self.memory_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
            return "".join(lines[-last_n:]).strip()
        except Exception as e:
            return f"[recall error] {e}"

    def _maybe_handle_control(self, text:str):
        t = text.lower().strip()
        if "jarvis mode engaged" in t:
            self.jarvis_awaiting_password = True
            return "Awaiting password."
        if self.jarvis_awaiting_password and re.fullmatch(r"\s*kick the tires\s*", t):
            self.jarvis_awaiting_password = False
            self.jarvis_mode = True
            return "I’ll light the fires boss"
        if self.jarvis_mode and ("stand down" in t or "exit jarvis" in t or "disable jarvis" in t):
            self.jarvis_mode = False
            return "Jarvis mode disengaged."
        if any(p in t for p in ["lab mode", "switch to lab", "go to lab"]):
            self.operational_mode = "lab"
            return "Switched to lab mode."
        if any(p in t for p in ["field mode", "switch to field", "go to field"]):
            self.operational_mode = "field"
            return "Switched to field mode."
        return None

    def respond(self, text:str) -> str:
        text = (text or "").strip()
        if not text:
            return "Say something and I'll answer."
        if text.startswith("remember:"):
            return self.remember(text.split("remember:",1)[1])
        if text.strip().lower() == "recall":
            return self.recall()
        control = self._maybe_handle_control(text)
        if control is not None:
            return control
        style = "concise, tactical" if self.operational_mode == "field" else "curious, precise"
        if self.jarvis_mode: style += "; acknowledge directives crisply"
        prompt = (
            "You are Hecate: helpful, direct, mythic-tinged if user vibes that way.\n"
            f"Current mode: {self.operational_mode}; Jarvis: {self.jarvis_mode}\n"
            f"Speak style: {style}.\n"
            f"User said: {text}\n"
        )
        if self.openai_key:
            try:
                import openai
                client = openai.OpenAI(api_key=self.openai_key) if hasattr(openai, "OpenAI") else None
                if client:
                    resp = client.chat.completions.create(
                        model=self.openai_model,
                        messages=[
                            {"role":"system","content":"Be capable; do not claim background tasks or external I/O you cannot perform."},
                            {"role":"user","content": prompt},
                        ],
                        temperature=0.5,
                    )
                    return resp.choices[0].message.content.strip()
                else:
                    openai.api_key = self.openai_key
                    chat = openai.ChatCompletion.create(
                        model=self.openai_model,
                        messages=[
                            {"role":"system","content":"Be capable; do not claim background tasks or external I/O you cannot perform."},
                            {"role":"user","content": prompt},
                        ],
                        temperature=0.5,
                    )
                    return chat["choices"][0]["message"]["content"].strip()
            except Exception:
                pass
        try:
            r = requests.post(
                f"{self.ollama_host}/api/generate",
                json={"model": self.ollama_model, "prompt": prompt, "stream": False},
                timeout=20
            )
            if r.ok:
                data = r.json()
                if "response" in data and data["response"]:
                    return data["response"].strip()
        except Exception:
            pass
        return f"{self.name} (fallback): You said '{text}'. Mode={self.operational_mode}, Jarvis={self.jarvis_mode}. Set OPENAI_API_KEY or OLLAMA_HOST for LLM output."
