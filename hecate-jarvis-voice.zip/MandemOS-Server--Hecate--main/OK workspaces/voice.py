
import os, base64, requests

ELEVEN_API_KEY = os.getenv("ELEVEN_API_KEY")
ELEVEN_VOICE_ID = os.getenv("ELEVEN_VOICE_ID", "21m00Tcm4TlvDq8ikWAM")
ELEVEN_MODEL_ID = os.getenv("ELEVEN_MODEL_ID", "eleven_multilingual_v2")

def eleven_tts_mp3(text:str, voice_id:str=None, stability:float=0.4, similarity_boost:float=0.8)->bytes:
    if not ELEVEN_API_KEY:
        raise RuntimeError("ELEVEN_API_KEY not set")
    v = voice_id or ELEVEN_VOICE_ID
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{v}"
    headers = {"xi-api-key": ELEVEN_API_KEY, "accept": "audio/mpeg", "content-type": "application/json"}
    payload = {"text": text, "model_id": ELEVEN_MODEL_ID, "voice_settings": {"stability": stability, "similarity_boost": similarity_boost}}
    r = requests.post(url, headers=headers, json=payload, timeout=60)
    r.raise_for_status()
    return r.content

def as_b64_audio_mp3(raw:bytes)->str:
    return "data:audio/mpeg;base64," + base64.b64encode(raw).decode("ascii")
