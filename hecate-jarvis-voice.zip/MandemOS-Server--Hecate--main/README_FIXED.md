
# Hecate — Working Server (Jarvis + Voice)

## Endpoints
- `POST /api/respond` — text in, text out
- `GET /api/state` — `{mode, jarvis, awaiting_password}`
- `POST /api/voice/ingest?tts=1` — audio in → transcribe (OpenAI Whisper) → respond → (optional) TTS (ElevenLabs). Returns JSON (and base64 audio if `tts=1`).
- `POST /api/voice/speak` — `{text, voice_id?}` → MP3 bytes
- `GET /api/voice/voices` — list

## Jarvis Mode
1) "Jarvis mode engaged" → "Awaiting password."
2) "kick the tires" → "I’ll light the fires boss" (Jarvis ON)
Say "lab mode" / "field mode" anytime.

## Env
- `OPENAI_API_KEY` for LLM + Whisper
- `OPENAI_MODEL` (default `gpt-4o-mini`)
- `OLLAMA_HOST` (default `http://localhost:11434`) + `OLLAMA_MODEL` (default `llama3`)
- `ELEVEN_API_KEY` + optional `ELEVEN_VOICE_ID`

## Run
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export OPENAI_API_KEY=sk-...   # or configure Ollama
# optional voice
export ELEVEN_API_KEY=eleven-...

python server.py
```
